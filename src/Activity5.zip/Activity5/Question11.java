package Activity5;

public class Question11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static int extractFirstInteger(int number) {
		
		int firstInteger = 0;
		return firstInteger;
		
	}

}
